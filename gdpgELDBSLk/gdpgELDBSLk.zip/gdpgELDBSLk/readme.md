Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Crear una Clase en PHP?
Enlace: https://lopezpagan.com/como-crear-una-clase-en-php/