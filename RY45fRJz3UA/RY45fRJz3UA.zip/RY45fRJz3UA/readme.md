Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Hacer un Video Responsive con HTML y CSS?
Enlace: https://lopezpagan.com/como-hacer-un-video-responsive-con-html-y-css/