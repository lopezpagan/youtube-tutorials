Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Mostrar Resultados en Formato JSON con MySQL y PHP?
Enlace: https://lopezpagan.com/como-mostrar-resultados-en-formato-json-con-mysql-y-php/