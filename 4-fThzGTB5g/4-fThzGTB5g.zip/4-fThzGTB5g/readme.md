Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Auto-Completar Un Formulario?
Enlace: https://lopezpagan.com/como-auto-completar-un-formulario/