Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Crear Una Aplicación Web Para Móviles?
Enlace: https://lopezpagan.com/como-crear-una-aplicacion-web-para-moviles/