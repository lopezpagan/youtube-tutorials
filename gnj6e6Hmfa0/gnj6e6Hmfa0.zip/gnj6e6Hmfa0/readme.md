Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Alinear Imagen en DIV Verticalmente con CSS y HTML?
Enlace: https://lopezpagan.com/como-alinear-imagen-en-div-verticalmente-con-css-y-html/