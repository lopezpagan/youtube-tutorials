Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Hacer que la Imagen de Fondo Cubra Toda la Pantalla HTML y CSS?
Enlace: https://lopezpagan.com/la-imagen-fondo-cubra-toda-la-pantalla-html-css/