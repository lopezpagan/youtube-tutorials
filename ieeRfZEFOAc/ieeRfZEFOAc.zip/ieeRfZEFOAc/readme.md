Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Listar, Añadir, Editar, Borrar Records con Dreamweaver y PHP?
Enlace: https://lopezpagan.com/listar-anadir-editar-borrar-records-con-dreamweaver-y-php/