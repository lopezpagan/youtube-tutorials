<link rel="stylesheet" type="text/css" href="css/cart-style.css">

<div class="action-link">
<a href="#" class="action-link">
A&ntilde;adir producto</a> </div>

<div class="action-link">
<a href="#" class="action-link">
Regresar</a> </div>

<div class="row list-text-title">
	<div class="col2">Name</div>
	<div class="col2">SEO</div>
	<div class="col2">Price</div>
	<div class="col2">Category</div>
	<div class="col2">Status</div>
	<div class="col2">Actions</div>
</div>
<div class="row">
	<div class="col2">Name</div>
	<div class="col2">SEO</div>
	<div class="col2">Price</div>
	<div class="col2">Category</div>
	<div class="col2">Status</div>
	<div class="col2">Actions</div>
</div>
<hr/>
<div class="form">
	<div class="row-item form-title">Title</div>
	<div class="row-item form-input"><input name="" type="text"></div>
	<div class="row-item form-title">Title</div>
	<div class="row-item form-input"><input name="" type="text"></div>
</div>
<hr/>
<div class="row">
	<h1>h1</h1>
	<h2>h2</h2>
	<h3>h3</h3>
	<h4>h4</h4>
	<h5>h5</h5>
	<h6>h6</h6>
</div>