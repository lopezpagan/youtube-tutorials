Autor: Tony López Pagán
Sitio web: lopezpagan.com

Tutorial: ¿Cómo Crear Un Campo de Selección Básico/Intermedio/Avanzado?
Enlace: 
https://lopezpagan.com/como-crear-un-campo-de-seleccion-en-html-y-php-nivel-basico/
https://lopezpagan.com/crear-campo-seleccion-html-php-nivel-intermedio/
https://lopezpagan.com/crear-campo-seleccion-htmljson-php-nivel-avanzado/